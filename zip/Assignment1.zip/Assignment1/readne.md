To run tests:
``` make test_numbers && ./test_numbers ```